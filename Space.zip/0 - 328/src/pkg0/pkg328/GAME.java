package pkg0.pkg328;





import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultListModel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;


public class GAME extends javax.swing.JFrame {

    Socket socket;
    BufferedReader in;
    PrintWriter out;
    String name;
    String serverResponse;
    int elapsedTime = 0;
    boolean doneTimer =false;
    boolean isThree=false;
    boolean correctAnswerReceived = false;
    boolean noOneAnswer=true;
    boolean game=false;
   
    /**
     * Creates new form GAME
     */
    public GAME() {
        
        initComponents();
        jPanel2.setVisible(false);
        jPanel3.setVisible(false);
        jPanel1.setVisible(false);
        showPanel(jPanel4);
       
        
    }
   // 192.168.100.92
private void connecting() {
    try {
        socket = new Socket("localhost", 9898);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);
        
        // Send "connect" to the server to indicate that the client has connected
         serverResponse();
        out.println("connect");
        out.println(name);
        showPanel(jPanel1);
    } catch (IOException ex) {
        Logger.getLogger(GAME.class.getName()).log(Level.SEVERE, null, ex);
    }
}

private void sendConnectedGameUsersList(String score) {
      DefaultListModel<String> model = new DefaultListModel<>(); // Create a new DefaultListModel

    // Split the input string by comma to get individual player names
    String[] playerNames = score.split(",");

    // Add each player name to the model
    for (String playerName : playerNames) {
        model.addElement(playerName);
    }

    // Set the model to the connectedList GUI component
    ScoreList.setModel(model);
 }

 private void sendConnectedRoomUsersList(String room) {
      DefaultListModel<String> model = new DefaultListModel<>(); // Create a new DefaultListModel

    // Split the input string by comma to get individual player names
    String[] playerNames = room.split(",");

    // Add each player name to the model
    for (String playerName : playerNames) {
        model.addElement(playerName);
    }

    // Set the model to the connectedList GUI component
    waitingList.setModel(model);
 }

private void sendConnectedUsersList(String con) {
    DefaultListModel<String> model = new DefaultListModel<>(); // Create a new DefaultListModel

    // Split the input string by comma to get individual player names
    String[] playerNames = con.split(",");

    // Add each player name to the model
    for (String playerName : playerNames) {
        model.addElement(playerName);
    }

    // Set the model to the connectedList GUI component
    connectedList.setModel(model);
}

private void serverResponse() {
            Thread t = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        while (true) {
                            serverResponse = in.readLine();
                            
                            if (serverResponse!=null) {
                                
                              //  System.out.println("SERVER: " + serverResponse);
                                
                                 
                                if (serverResponse.contains("Connected users:"))
                                {
                                    
                                    sendConnectedUsersList(serverResponse.substring(16));// Remove "Connected users:" prefix
                                
                                }
                                else if (serverResponse.contains("Room members:" )){
                                    sendConnectedRoomUsersList(serverResponse.substring(13));// Remove "Room members:" prefix
                                    
                                } else if (serverResponse.contains("Users scores:" )){
                                    sendConnectedGameUsersList(serverResponse.substring(13));// Remove "Users scores:" prefix
                                    
                                }
                                else if (serverResponse.contains("Question: ")){
                                     states.setText("Try to answer the question quickly.");
                                     questions.setText(serverResponse);
                                }
                                else if (serverResponse.equals("correct")){
                                    noOneAnswer=false;
                                     states.setText("Try to answer the question quickly.");
                                    
                                } 
                                else if (serverResponse.equals("cannot play alone")){
                                 JOptionPane.showMessageDialog(GAME.this, serverResponse, "", JOptionPane.ERROR_MESSAGE);
                                 setVisible(false);
                                }
                                else if (serverResponse.equals("wrong")){
                                    states.setText("NO, it's wrong try agaon !");
                                }
                                else if (serverResponse.equals("You are already in a room.")){
                                  JOptionPane.showMessageDialog(GAME.this, serverResponse, "", JOptionPane.ERROR_MESSAGE);
                                }
                                else if (serverResponse.equals("The room is full. Please try again later.")){
                                  JOptionPane.showMessageDialog(GAME.this, "The room is full.", "Try again later", JOptionPane.ERROR_MESSAGE);
                                }

                                    else if (serverResponse.equals("num is three")){
                                       isThree=true;

                                       showPanel(jPanel3);
                                       out.println("start the game");
                                      Thread timerThread = new Thread(() -> {
            try {
                
                 int timer = 0;
                while (timer < 30) { 
                    Thread.sleep(1000);
                    timer++;
                    jLabel7.setText("Timer : "+timer);
                }
                 out.println("is no one answet ?");      
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        timerThread.start();
                                    
                                }   else if (serverResponse.equals("no one answer")){
                                     JOptionPane.showMessageDialog(GAME.this, "Game Ended!! there is no winner.", "Times out!", JOptionPane.ERROR_MESSAGE);
                                    setVisible(false );
                                }
                                    
                                    
                                    else if (serverResponse.equals("The game is started. Please try again later.")){
                                   JOptionPane.showMessageDialog(GAME.this, "The game is started.", "Try again later", JOptionPane.ERROR_MESSAGE);
                                }
                               else if (serverResponse.equals("wait for others")){
                                    showPanel(jPanel2);
                                }
                                else if (serverResponse.equals("timer")){
                                    showPanel(jPanel2);
                                      Thread timerThread = new Thread(() -> {
            try {
                
                 int timer = 0;
                 System.out.println("start timer");
                while (timer < 30  && ! game) { 
                    Thread.sleep(1000);
                    timer++;
                    jLabel5.setText("Timer : "+timer);
                }
               showPanel(jPanel3);
                                       out.println("start the game");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });
        timerThread.start();
                                }
                                else if (serverResponse.contains("player With Highest Score : ")){
                                     JOptionPane.showMessageDialog(GAME.this, serverResponse, "winner", JOptionPane.INFORMATION_MESSAGE);
                               setVisible(false );
                                }
                                
                                else if (serverResponse.contains("GameTimer : ")) {
                                
       game = true;
    Thread timerThread = new Thread(() -> {
        try {
            int timer = 0;
            while (timer < 30 && game) { 
                Thread.sleep(1000);
                timer++;
                jLabel7.setText("Timer : " + timer);
            }
            out.println("is no one answet ?"); // This line sends the message
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    });
    timerThread.start();

        
                            }
                        }
                        }
                    } catch (IOException ex) {
                        System.out.println(ex.getMessage());
                    }
                }
            });
            t.start();
        }

private void showPanel(JPanel panel) {
    jPanel1.setVisible(panel == jPanel1);
    jPanel2.setVisible(panel == jPanel2);
    jPanel3.setVisible(panel == jPanel3);
    jPanel4.setVisible(panel == jPanel4);
}



    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLayeredPane1 = new javax.swing.JLayeredPane();
        jPanel4 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        connect = new javax.swing.JButton();
        jTextField2 = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel9 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        connectedList = new javax.swing.JList<>();
        play = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        waitingList = new javax.swing.JList<>();
        jLabel5 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        ScoreList = new javax.swing.JList<>();
        questions = new javax.swing.JLabel();
        states = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        send = new javax.swing.JButton();
        jLabel7 = new javax.swing.JLabel();
        leave = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel4.setBackground(new java.awt.Color(0, 0, 0));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("Enter your name : ");
        jPanel4.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(232, 127, 122, -1));

        connect.setText("Connect");
        connect.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                connectActionPerformed(evt);
            }
        });
        jPanel4.add(connect, new org.netbeans.lib.awtextra.AbsoluteConstraints(252, 213, 75, -1));

        jTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField2ActionPerformed(evt);
            }
        });
        jPanel4.add(jTextField2, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 165, 201, -1));
        jPanel4.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkg0/pkg328/photo1711922213.jpeg"))); // NOI18N
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 570, 380));

        jPanel1.setBackground(new java.awt.Color(0, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setForeground(new java.awt.Color(255, 255, 255));
        jLabel1.setText("Connected players :");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 32, -1, -1));

        connectedList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { " " };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(connectedList);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(17, 54, 150, 272));

        play.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        play.setText("Play");
        play.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                playActionPerformed(evt);
            }
        });
        jPanel1.add(play, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 130, 87, 32));

        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("Are you ready? ");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 100, 130, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkg0/pkg328/photo1711922213.jpeg"))); // NOI18N
        jLabel8.setText("jLabel8");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 510, -1));

        jPanel2.setBackground(new java.awt.Color(0, 0, 0));
        jPanel2.setForeground(new java.awt.Color(0, 153, 153));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("waiting players : ");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 15, -1, -1));

        waitingList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { " " };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane2.setViewportView(waitingList);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(29, 37, 118, 234));

        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("waiting ....");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(249, 123, 54, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkg0/pkg328/photo1711922213.jpeg"))); // NOI18N
        jPanel2.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 460, 350));

        jPanel3.setBackground(new java.awt.Color(0, 0, 0));
        jPanel3.setForeground(new java.awt.Color(0, 102, 102));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("Waiting players :");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 6, 87, -1));

        ScoreList.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { " " };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane3.setViewportView(ScoreList);

        jPanel3.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 28, 117, 276));

        questions.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        questions.setForeground(new java.awt.Color(255, 255, 255));
        questions.setText("Question ");
        jPanel3.add(questions, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 82, -1, -1));

        states.setForeground(new java.awt.Color(255, 255, 255));
        states.setText("Try to answer the question quickly.");
        jPanel3.add(states, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 120, -1, -1));

        jTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField1ActionPerformed(evt);
            }
        });
        jPanel3.add(jTextField1, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 142, 208, -1));

        send.setText("Send");
        send.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                sendActionPerformed(evt);
            }
        });
        jPanel3.add(send, new org.netbeans.lib.awtextra.AbsoluteConstraints(248, 142, 86, -1));

        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("0");
        jPanel3.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 38, -1, -1));

        leave.setBackground(new java.awt.Color(51, 0, 0));
        leave.setText("Leave");
        leave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                leaveActionPerformed(evt);
            }
        });
        jPanel3.add(leave, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 240, -1, -1));

        jLabel11.setIcon(new javax.swing.ImageIcon(getClass().getResource("/pkg0/pkg328/photo1711922213.jpeg"))); // NOI18N
        jPanel3.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 550, 360));

        jLayeredPane1.setLayer(jPanel4, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jPanel1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jPanel2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jLayeredPane1.setLayer(jPanel3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        javax.swing.GroupLayout jLayeredPane1Layout = new javax.swing.GroupLayout(jLayeredPane1);
        jLayeredPane1.setLayout(jLayeredPane1Layout);
        jLayeredPane1Layout.setHorizontalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 550, Short.MAX_VALUE)
            .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 544, Short.MAX_VALUE))
            .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, 544, Short.MAX_VALUE))
            .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 544, Short.MAX_VALUE))
            .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel4, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jLayeredPane1Layout.setVerticalGroup(
            jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 416, Short.MAX_VALUE)
            .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 416, Short.MAX_VALUE))
            .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel3, javax.swing.GroupLayout.DEFAULT_SIZE, 416, Short.MAX_VALUE))
            .addGroup(jLayeredPane1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(jPanel4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jLayeredPane1)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void sendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_sendActionPerformed
      String answer = jTextField1.getText();
      if (answer !=null&& !(answer.equals(""))){
          System.out.println("we send it ");
    out.println("answer" + answer); }// Send the answer to the server
    }//GEN-LAST:event_sendActionPerformed

    private void jTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField1ActionPerformed

    private void playActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_playActionPerformed
       
      out.println("Room");
      out.println(name);
      out.flush();
      serverResponse();
      //showPanel(jPanel2);
      
    }//GEN-LAST:event_playActionPerformed

    private void jTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField2ActionPerformed

    private void connectActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_connectActionPerformed
             name=jTextField2.getText();
            if (name.isEmpty()){
                JOptionPane.showMessageDialog(this, "Please enter your name ", "Try again", JOptionPane.ERROR_MESSAGE);
            }
            else{  
                connecting();
                
                
              
            }  
        
    }//GEN-LAST:event_connectActionPerformed

    private void leaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_leaveActionPerformed
       
        

        out.println("leave");
       // out.println(name);
 // Optionally, update the connected players list locally to reflect the player leaving
  //  DefaultListModel<String> model = (DefaultListModel<String>) connectedList.getModel();
   // model.removeElement(name); // Remove the player's name from the connected players list
        setVisible(false);

    
    }//GEN-LAST:event_leaveActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GAME.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GAME.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GAME.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GAME.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GAME().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JList<String> ScoreList;
    private javax.swing.JButton connect;
    private javax.swing.JList<String> connectedList;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    private javax.swing.JButton leave;
    private javax.swing.JButton play;
    private javax.swing.JLabel questions;
    private javax.swing.JButton send;
    private javax.swing.JLabel states;
    private javax.swing.JList<String> waitingList;
    // End of variables declaration//GEN-END:variables


}