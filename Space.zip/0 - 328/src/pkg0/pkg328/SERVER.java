package pkg0.pkg328;

import java.io.*;
import java.net.Socket;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.Iterator;


public class SERVER{
    
    private static ArrayList<NewClient> clients=new ArrayList<> () ;
    
public static void main (String[] args) throws IOException{
    
ServerSocket serversocket = new ServerSocket (9898);//يفتح بورت
while (true) {
System.out.println("Waiting to client connection");
Socket client=serversocket.accept () ;//ينتظر من الكلاينت 
System.out.println ("Connected to client");
NewClient clientThread=new NewClient (client,clients);//سوينا اوبجيكت للكلاين اللي وصل من نوع كلاينت ثريدارسلنا السوكت والاراي
clients.add (clientThread);// يضيف الكلاينت للاراي 
new Thread(clientThread).start() ;  

}
}
}


class NewClient implements Runnable
{
private Socket client;
private BufferedReader in;
private PrintWriter out;
private String userName;
private int score;
private boolean isInRoom;
private boolean noOneAnswer=true;
private static final int MAX_ROOM_CAPACITY = 3;
private ArrayList<NewClient> clients;
boolean isStarted=false;
    String[] scrambledWords = {"papel", "sernu", "tusdnet", "aeblt", "raihc"};
    String[] correctAnswers = {"apple", "nurse", "student", "table", "chair"};
  static int currentQuestionIndex = 0;


public NewClient (Socket c, ArrayList<NewClient> clients)throws IOException{
this.client=c;
this.clients=clients;
in= new BufferedReader (new InputStreamReader(client.getInputStream () ) ) ;//عشان انا كسيرفر اقدر اتواصل مع كلاينت معين او كلهم
out=new PrintWriter(client.getOutputStream() ,true);//نفس الشي 
this.score=0;
this.isInRoom = false;

}
@Override
public void run ()
{
    try{
        String fromClient;
 while (true){
         if((fromClient = in.readLine()) != null) {
             
             System.out.println(fromClient);
        if (fromClient.equals("connect")) {
                            userName = in. readLine();
                            System.out.println( userName + " has Connected");
                            sendConnectedUsersList();
                            
        }else if (fromClient.equals("Room")) {
                            userName = in. readLine();
                            joinRoom(userName);
                            System.out.println("before room list");
                          if(!this.isStarted){
                              System.out.println("IN IF "); 
                            sendConnectedUsersList();
                            forwrd();
                            sendConnectedRoomUsersList();}
                            
                        }else if (fromClient.equals("start the game")){
                            for (NewClient member : clients){
                                 member.out.println("GameTimer : ");
                             member.isStarted=true;
                             member.out.flush();
                           }
                           System.out.println("befor the SCORE"); 
                            sendConnectedGameUsersList();
                           startGame();
                        }
                        else if (fromClient.contains("answer")) {
    String clientAnswer = fromClient.substring(6); // Extract the answer
    
    if (!clientAnswer.isEmpty()) {
        System.out.println(this.userName + " answers: " + clientAnswer);
        if (clientAnswer.equalsIgnoreCase(correctAnswers[currentQuestionIndex])) {
            out.println("correct");
            System.out.println(this.userName + " is correct");
            this.score++;
            currentQuestionIndex++;
             for (NewClient client : clients) {
                if(client.isInRoom){
            client.noOneAnswer=false;}}
            sendConnectedGameUsersList();
            startGame();
        } else {
            out.println("wrong");
            System.out.println(this.userName + " is wrong");
        }
    }
}
                        else if (fromClient.equals("leave")) {

               handlePlayerLeave(this.userName);
               sendConnectedGameUsersList();
                numplayer();
                this.isInRoom=false;
                break; // Exit the loop as the player has left
            }
         else if (fromClient.equals("is no one answet ?")) {
              for (NewClient client : clients) {
                if(client.isInRoom){
             if(client.noOneAnswer){

                    client.out.println("no one answer");
        
             }
             else if(!client.noOneAnswer && currentQuestionIndex>0 ){
                   client.winner();
             }}}
         }


        
 }
} 
    }catch (IOException ex) {
            }
}

private void sendConnectedGameUsersList() {
            String Score = "Users scores:";
           
            for (NewClient client : clients) {
                if(client.isInRoom){
                    System.out.println(userName+"in SCORE");
                Score+= client.userName+" -> Score : "+client.score+",";}//اجمعهم وافصلهم بفاصله 
            }
             for (NewClient client : clients) {
                if(client.isInRoom){
                     client.out.println(Score);
                }
            
            
        }}


        private void sendConnectedUsersList() {
            String Connected = "Connected users:";
           
            for (NewClient client : clients) {
                if(client.isInRoom){
                Connected+= client.userName+">>In Room"+",";}//اجمعهم وافصلهم بفاصله 
                else{ Connected+= client.userName+",";}
            }
             for (NewClient client : clients) {
                client.out.println(Connected);
            
            
        }}
        
        
          private void sendConnectedRoomUsersList() {
          String InRoom = "Room members:";
              
              
          for (NewClient member : clients) {
              member.out.flush();
              if(member.isInRoom){
                InRoom+= member.userName+",";//اجمعهم وافصلهم بفاصله 
            }}
             for (NewClient member : clients) {
                  if(member.isInRoom){
                     member.out.println(InRoom);
        }
             }
        }
          
  
          
private void joinRoom(String name){
    int num=0;
 for (NewClient member : clients) {
                  if(member.isInRoom && !member.isStarted){
                      num++;
                  }}
 if (this.isInRoom) {
      //  out.println("You are already in a room.");
        return;
    }
 else if (num >= MAX_ROOM_CAPACITY) {
        out.println("The room is full. Please try again later.");
        return;
    }
       else if (this.isStarted) {
        out.println("The game is started. Please try again later.");
        return;
    }
 

  this.isInRoom=true;
    System.out.println(name+" has entered the room.");
}


public void numplayer() throws IOException{
      int num=0;
 for (NewClient member : clients) {
                  if(member.isInRoom ){
                      num++;
                  }}
 
  if(num==1){
        for (NewClient member : clients) {
                  if(member.isInRoom){
        member.out.println("cannot play alone");
        member.client.close();
        member.in.close();
        member.out.close();
        }}
    }    
}



 private void forwrd() throws IOException{
      int num=0;
 for (NewClient member : clients) {
                  if(member.isInRoom && !member.isStarted){
                      num++;
                  }}

    if(num==1){
        for (NewClient member : clients) {
                  if(member.isInRoom){
        member.out.println("wait for others");
        System.out.println(" num=1");}}
    }    
    
    else if(num==2){for (NewClient member : clients) {
                  if(member.isInRoom && !member.isStarted){
        member.out.println("timer");
        }}
   
      } 
    
    else if(num==3){ for (NewClient member : clients) {
                  if(member.isInRoom && !member.isStarted){
                      System.out.println("its true"); 
        member.out.println("num is three");
        System.out.println("num=3");}}
    
    }
    
    
   
 }
 
 
    private void startGame() throws IOException {
          
     while (currentQuestionIndex < scrambledWords.length) {
          String question = scrambledWords[currentQuestionIndex];
           for (NewClient member : clients) {
                  if(member.isInRoom){
                    member.out.println("Question: " + question);
                     member.out.flush();
                     
                  }}
         break;
     }
   if(currentQuestionIndex==5){
        this.winner();
   }
}
private void winner() {
    int highestScore = 0;
    String playerWithHighestScore = "";

    // Find the player with the highest score
    for (NewClient member : clients) {
        if (member.isInRoom) {
            if (member.score > highestScore) {
                highestScore = member.score;
                playerWithHighestScore = member.userName;
            }
        }
    }

    // Send the message about the winner to all clients in the room
    for (NewClient member : clients) {
        if (member.isInRoom) {
            member.out.println("player With Highest Score : " + playerWithHighestScore);
        }
    }
}




private void handlePlayerLeave(String name) {
    // Create an iterator to safely remove elements
    Iterator<NewClient> iterator = clients.iterator();
    
    // Iterate over the clients
    while (iterator.hasNext()) {
        NewClient client = iterator.next();
        
        // Check if the client's name matches the specified name
        if (client.userName.equals(name)) {
            try {
                // Close the client's socket
                client.client.close();
                client.in.close();
                client.out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            
            // Remove the client using the iterator
            iterator.remove();
            
            // Stop the client thread
            break; // Break the loop since we found and removed the client
        }
    }
}


}



 